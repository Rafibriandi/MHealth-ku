package com.example.tugasakhir2

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SubEdukasiActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.subedukasi)

        val subEdukasiImageView = findViewById<ImageView>(R.id.gambaredukasi)
        val subEdukasiTextView = findViewById<TextView>(R.id.tulisanedukasi)

        val imageResource = intent.getIntExtra("image_resource", 0)
        val tulisan = intent.getStringExtra("tulisan")

        if (imageResource != 0) {
            subEdukasiImageView.setImageResource(imageResource)
        }
        if(tulisan!=null){
        subEdukasiTextView.text= tulisan.toString()
       }

    }
}