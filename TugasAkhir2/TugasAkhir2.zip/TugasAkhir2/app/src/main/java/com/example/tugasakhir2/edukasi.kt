package com.example.tugasakhir2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class EdukasiActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.edukasi)



        val buttons = arrayOf(
            findViewById<Button>(R.id.opsi_edukasi1),
            findViewById<Button>(R.id.opsi_edukasi2),
            findViewById<Button>(R.id.opsi_edukasi3)
        )

        val textview = arrayOf(
            findViewById<TextView>(R.id.TextView1),
            findViewById<TextView>(R.id.TextView2),
            findViewById<TextView>(R.id.TextView3),
        )

        val imageResourceIds = arrayOf(
            R.drawable.rectangle1,
            R.drawable.rectangle1,
            R.drawable.rectangle1,
        )
        val text = arrayOf(
            "Minum bunda minimal 5 kali sehari",
            "Minum bunda minimal 10 kali sehari",
            "Minum bunda minimal 15 kali sehari",
        )

        for (i in buttons.indices) {
            buttons[i].setOnClickListener {
                val intent = Intent(this, SubEdukasiActivity::class.java).apply {
                    putExtra("image_resource", imageResourceIds[i])
                    putExtra("tulisan", text[i])
                }
                startActivity(intent)
            }
        }
    }
}