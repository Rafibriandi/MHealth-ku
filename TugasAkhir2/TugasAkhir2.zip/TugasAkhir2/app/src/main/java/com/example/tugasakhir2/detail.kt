package com.example.tugasakhir2

import android.os.Bundle
import android.os.PersistableBundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.tugasakhir2.databinding.Opsidata2Binding
import com.example.tugasakhir2.databinding.OpsidatadetailBinding


class DetailActivity : AppCompatActivity() {

private lateinit var binding: OpsidatadetailBinding
var b : Bundle ? = null

  override fun onCreate(savedInstanceState: Bundle?){
      super.onCreate(savedInstanceState)
      binding = OpsidatadetailBinding.inflate(layoutInflater)
      setContentView(binding.root)
      initview()

  }
    fun initview(){
    b = intent.extras
    binding.nama.text = b?.getString("nama")
        binding.jk.text = b?.getString("jk")
        binding.alamat.text = b?.getString("alamat")
    }
 }



