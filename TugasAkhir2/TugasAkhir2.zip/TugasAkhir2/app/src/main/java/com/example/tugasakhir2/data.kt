package com.example.tugasakhir2

import java.util.*

class data {
    var nomorindek : String = ""
    private var ibu :String = ""
    private var suami :String = ""
    private var umur :String = ""
    private var alamat :String = ""
    private var hpht :String = ""
    private var usia_hamil :String = ""
    private var perkiraan :String = ""
    private var hamil_ke :String = ""

    constructor(nomorindek : String, ibu : String, suami :String, alamat :String, umur :String, hpht :String, usia_hamil :String, perkiraan :String, hamil_ke :String,){
        this.nomorindek = nomorindek
        this.ibu = ibu
        this.suami = suami
        this.alamat = alamat
        this.umur = umur
        this.hpht = hpht
        this.usia_hamil = usia_hamil
        this.perkiraan = perkiraan
        this.hamil_ke = hamil_ke



    }
fun getnomorindek() : String {
return nomorindek
}
    fun getibu() : String {
        return ibu
    }
    fun getsuami() : String {
        return suami
    }
    fun getalamat() : String {
        return alamat
    }
    fun getumur() : String {
        return umur
    }
    fun gethpht() : String {
        return hpht
    }
    fun getusiahamil() : String {
        return usia_hamil
    }
    fun getperkiraan() : String {
        return perkiraan
    }
    fun gethamilke() : String {
        return hamil_ke
    }
}