package com.example.tugasakhir2
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import java.io.Serializable
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.HashMap

class IsiDataActivity : AppCompatActivity() {

    private lateinit var nomorindek: EditText
    private lateinit var ibu: EditText
    private lateinit var suami: EditText
    private lateinit var alamat: EditText
    private lateinit var umur: EditText
    private lateinit var hpht: EditText
    private lateinit var u_kehamilan: EditText
    private lateinit var perkiraan_lahir: EditText
    private lateinit var hamil_ke: EditText
    private lateinit var lanjutButton: Button

    private val url = "http://10.0.2.2/ta%202/trial2.php" // Ganti dengan IP server Anda jika diperlukan
    private val myCalendar = Calendar.getInstance()

    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.identitas1)

        nomorindek = findViewById(R.id.nomorindek)
        lanjutButton = findViewById(R.id.lanjut_button)
        ibu = findViewById(R.id.ibu)
        suami = findViewById(R.id.suami)
        alamat= findViewById(R.id.alamat)
        umur = findViewById(R.id.umur)
        hpht = findViewById(R.id.hpht)
        u_kehamilan = findViewById(R.id.usia_kehamilan)
        perkiraan_lahir = findViewById(R.id.perkiraan_lahir)
        hamil_ke = findViewById(R.id.hamil_ke)


        val fragment2 = halaman2data()
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fragment_container,fragment2)
        }


//        tanggalEditText.setOnClickListener {
//            // Tampilkan DatePickerDialog
//            val date = DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
//                // Update myCalendar dengan tanggal yang dipilih
//                myCalendar.set(Calendar.YEAR, year)
//                myCalendar.set(Calendar.MONTH, monthOfYear)
//                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
//
//                // Format tanggal menggunakan SimpleDateFormat
//                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
//                tanggalEditText.setText(dateFormat.format(myCalendar.time))
//            }
//
//            // Tampilkan DatePickerDialog
//            DatePickerDialog(this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH)).show()
//        }

//        val opsi = listOf("L", "P")
//        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, opsi)
//        jkEditText.setAdapter(adapter)

        lanjutButton.setOnClickListener {
            val nomorindek = nomorindek.text.toString()
            val ibu = ibu.text.toString()
            val suami = suami.text.toString()
            val alamat = alamat.text.toString()
            val umur = umur.text.toString()
            val hpht = hpht.text.toString()
            val u_kehamilan = u_kehamilan.text.toString()
            val perkiraan_lahir = perkiraan_lahir.text.toString()
            val hamil_ke = hamil_ke.text.toString()

            val fragment2 = halaman2data()
            val bundle = Bundle()
            bundle.putString("nomorindek", nomorindek)
            bundle.putString("ibu", ibu)
            bundle.putString("suami", suami)
            bundle.putString("alamat", alamat)
            bundle.putString("umur", umur)
            bundle.putString("hpht", hpht)
            bundle.putString("ukehamilan", u_kehamilan)
            bundle.putString("perkiraanlahir", perkiraan_lahir)
            bundle.putString("hamilke", hamil_ke)
            fragment2.arguments = bundle

            supportFragmentManager.beginTransaction().apply {
                replace(R.id.fragment_container, fragment2)
                commit()
            }
        }
    }
}


//
//            if (nama.isNotEmpty() && tanggal.isNotEmpty() && jk.isNotEmpty()   ) {
//                simpan(nama, tanggal, jk, )
//            } else {
//                Toast.makeText(this, "Mohon mengisi semua kolom", Toast.LENGTH_SHORT).show()
//            }
//        }
//    }
//
//    private fun simpan(nama: String, tanggal: String, jk: String ) {
//        val requestQueue = Volley.newRequestQueue(this)
//        val stringRequest = @SuppressLint("ResourceType")
//        object : StringRequest(
//            Request.Method.POST, url,
//            Response.Listener { response ->
//                val jsonObject = JSONObject(response)
//                val serverResponseArray = jsonObject.getJSONArray("server_response")
//                val firstObjectInArray = serverResponseArray.getJSONObject(0)
//                val success = firstObjectInArray.getString("status")
//
//                if (success == "OK" && nama.isNotEmpty()&&tanggal.isNotEmpty() &&jk.isNotEmpty() ) {
//                    val resultIntent = Intent().apply {
//                        putExtra("mitoma", arrayListOf(nama, tanggal, jk, ))
//                    }
//                    setResult(Activity.RESULT_OK, resultIntent)
//                    finish()
//                    val fragment2 = halaman2data()
//                    supportFragmentManager.beginTransaction().apply {
//                        replace(R.layout.identitas1,fragment2)
//                    }
//                } else {
//                    Toast.makeText(this, "Gagal menyimpan data", Toast.LENGTH_SHORT).show()
//                }
//            },
//            Response.ErrorListener { error ->
//                // Tampilkan pesan error
//                Toast.makeText(this, "Terjadi kesalahan: ${error.message}", Toast.LENGTH_SHORT).show()
//            }
//        ) {
//            override fun getParams(): MutableMap<String, String> {
//                val params = HashMap<String, String>()
//                params["Nama"] = nama
//                params["Tanggal"] = tanggal
//                params["JK"] = jk
//
//                return params
//            }
//        }
//
//        requestQueue.add(stringRequest)
//    }}




