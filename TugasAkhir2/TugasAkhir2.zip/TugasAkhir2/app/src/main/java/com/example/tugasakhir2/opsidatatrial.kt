package com.example.tugasakhir2

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.SearchView
import android.widget.TableLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.adapter.Adapterdata
import com.example.tugasakhir2.databinding.Opsidata2Binding



class opsidatatrialActivity : AppCompatActivity() {
    private lateinit var binding: Opsidata2Binding
    private lateinit var adapterdata: Adapterdata
    private val adddata: MutableList<data> = ArrayList()
    private val selectedData = mutableSetOf<Array<String>>()
    private val lm = LinearLayoutManager(this)


    companion object {
        const val REQUEST_ADD_DATA = 1
    }

    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = Opsidata2Binding.inflate(layoutInflater)
        setContentView(binding.root)






        initView()


    }

    private fun initView() {
        // Initialize adapter and RecyclerView
        adapterdata = Adapterdata(this)
        binding.view.adapter = adapterdata
        binding.view.layoutManager = lm

         //Add data to the adapter
//       adddata.add(data(nomorindek = "Razi", ibu = "L", alamat = "aceh"))
//       adddata.add(data(nama = "Deniwa", jk = "L", alamat = "meulaboh"))
//       adddata.add(data(nama = "Z", jk = "p", alamat = "sumatera"))
//       adapterdata.setlistdata(adddata)

        // Set up search bar functionality using binding
        binding.searchBaret.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val filteredList = mutableListOf<data>()
                for (item in adddata) {
                    if (item.nomorindek?.contains(s.toString(), ignoreCase = true) == true) {
                        filteredList.add(item)
                    }
                }
                adapterdata.setlistdata(filteredList)
            }
        })

        // Set up "Tambah Data" button
        binding.tambahDataButton.setOnClickListener {
            startActivityForResult(
                Intent(this, IsiDataActivity::class.java),
                OpsiDataActivity.REQUEST_ADD_DATA
            )
        }
    }

   override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == OpsiDataActivity.REQUEST_ADD_DATA && resultCode == Activity.RESULT_OK && data != null) {
            data?.let {
                val newData = data.getSerializableExtra("mitoma") as? ArrayList<String>
                if (newData != null) {
                    val nomorindek = newData[0]
                    val ibu = newData[1]
                    val suami= newData[2]
                    val alamat = newData[3]
                    val umur = newData[4]
                    val hpht = newData[5]
                    val usia_hamil = newData[6]
                    val perkiraan = newData[7]
                    val hamil_ke = newData[8]
                    val newDataObj = data(nomorindek = nomorindek, ibu = ibu, suami = suami,alamat=alamat,umur=umur,hpht=hpht, usia_hamil = usia_hamil, perkiraan = perkiraan, hamil_ke = hamil_ke)
                    adddata.add(newDataObj)
                    adapterdata.setlistdata(adddata)
                }
            }
        }
    }


}





