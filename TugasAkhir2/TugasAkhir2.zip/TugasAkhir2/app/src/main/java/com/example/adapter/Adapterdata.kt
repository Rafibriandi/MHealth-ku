package com.example.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir2.DetailActivity
import com.example.tugasakhir2.R
import com.example.tugasakhir2.data

class Adapterdata (val context : Context): RecyclerView.Adapter<Adapterdata.Dataviewholder>() {
    private val mhs : MutableList<data> = mutableListOf()

    override fun getItemCount(): Int {
        return mhs.size

    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Dataviewholder {
        return Dataviewholder(LayoutInflater.from(context).inflate(R.layout.isirecycle,parent,false))
    }
    override fun onBindViewHolder(holder: Adapterdata.Dataviewholder, position: Int) {
        holder.bindmodel(mhs[position])
    }
    inner class Dataviewholder(item: View):RecyclerView.ViewHolder(item){
        val nomorindek : TextView = item.findViewById(R.id.nomorindek)
        val hpht : TextView = item.findViewById(R.id.hpht)
        val cv     :CardView = item.findViewById(R.id.cv)

        fun bindmodel(m:data){
            nomorindek.text = m.getnomorindek()
            hpht.text = m.gethpht()

            cv.setOnClickListener() {
                var i = Intent(context,DetailActivity::class.java).apply{

                    putExtra("nomorindek",m.getnomorindek())
                    putExtra("ibu",m.getibu())
                    putExtra("suami",m.getsuami())
                    putExtra("alamat",m.getalamat())
                    putExtra("umur",m.getumur())
                    putExtra("hpht",m.gethpht())
                    putExtra("ukehamilan",m.getusiahamil())
                    putExtra("perkiraanlahir",m.getperkiraan())
                    putExtra("hamilke",m.gethamilke())

                }
                context.startActivity(i)
            }
        }
    }
    fun setlistdata(data:List<data>) {
        mhs.clear()
        mhs.addAll(data)
        notifyDataSetChanged()

    }
}

