package com.example.tugasakhir2



import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class KirimDataActivity : AppCompatActivity() {

    private lateinit var searchBar: EditText
    private lateinit var tambahDataButton: Button
    private lateinit var pilihSemuaButton: Button
    private lateinit var kirimDataButton: Button
    private lateinit var dataTable: TableLayout

    private var allDataSelected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.kirimdata1)

        searchBar = findViewById(R.id.search_bar)
        tambahDataButton = findViewById(R.id.tambah_data_button)
        pilihSemuaButton = findViewById(R.id.pilih_semua_button)
        kirimDataButton = findViewById(R.id.kirim_data_button)
        dataTable = findViewById(R.id.data_table)

        // Hide the "Tambah Data" button as it's not needed in this activity
        tambahDataButton.visibility = View.GONE

        val selectedData = intent.getSerializableExtra("selected_data") as List<List<String>>
        for (data in selectedData) {
            addTableRow(data.toTypedArray(), selectable = true)
        }

        pilihSemuaButton.setOnClickListener {
            allDataSelected = !allDataSelected
            for (i in 0 until dataTable.childCount) {
                val tableRow = dataTable.getChildAt(i) as TableRow
                if (allDataSelected)

                    tableRow.setBackgroundColor(Color.YELLOW)
                else {
                    tableRow.setBackgroundColor(Color.TRANSPARENT)
                }
            }
        }

        kirimDataButton.setOnClickListener {
            // Implement functionality to send selected data
            val selectedData = mutableListOf<List<String>>()
            for (i in 0 until dataTable.childCount) {
                val tableRow = dataTable.getChildAt(i) as TableRow
                if (getBackgroundColor(tableRow.background) == Color.YELLOW) {
                    val rowData = mutableListOf<String>()
                    for (j in 0 until tableRow.childCount) {
                        val textView = tableRow.getChildAt(j) as TextView
                        rowData.add(textView.text.toString())
                    }
                    selectedData.add(rowData)
                }
            }

            // Do something with selected data, e.g., send it to a server
        }
    }

    private fun addTableRow(data: Array<String>, selectable: Boolean) {
        val tableRow = TableRow(this)
        tableRow.layoutParams = TableRow.LayoutParams(
            TableRow.LayoutParams.MATCH_PARENT,
            TableRow.LayoutParams.WRAP_CONTENT
        )

        for (item in data) {
            val textView = TextView(this)
            textView.text = item
            textView.setPadding(16, 8, 16, 8)
            tableRow.addView(textView)
        }

        if (selectable) {
            tableRow.setOnClickListener {
                if (getBackgroundColor(tableRow.background) == Color.YELLOW) {
                    tableRow.setBackgroundColor(Color.TRANSPARENT)
                } else {
                    tableRow.setBackgroundColor(Color.YELLOW)
                }
            }
        }

        dataTable.addView(tableRow)
    }
    private fun getBackgroundColor(drawable: Drawable): Int {
        if (drawable is ColorDrawable) {
            return drawable.color
        }
        return Color.TRANSPARENT
    }
}
