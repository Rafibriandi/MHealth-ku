package com.example.tugasakhir2
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.Serializable

class OpsiDataActivity : AppCompatActivity() {

    private lateinit var searchBar: EditText
    private lateinit var tambahDataButton: Button
    private lateinit var kirimDataButton: Button
    private lateinit var dataTable: TableLayout
    private val selectedData = mutableSetOf<Array<String>>()
    private val REQUEST_CODE_ISI_DATA = 1
    companion object {
        const val REQUEST_ADD_DATA = 1
    }
    val url = "http://10.0.2.2/ta%202/trial.php" // Ganti dengan IP server Anda jika diperlukan

    private var sampleData = mutableListOf(
        arrayOf("piyu", "John Doe" ),
        arrayOf("piya", "Jane Smith"),
        arrayOf("piyi", "Michael Brown" ),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.opsidata1)

        searchBar = findViewById(R.id.search_bar)
        tambahDataButton = findViewById(R.id.tambah_data_button)
        kirimDataButton = findViewById(R.id.kirim_data_button)
        dataTable = findViewById(R.id.data_table)

        initData()

        tambahDataButton.setOnClickListener {
            startActivityForResult(Intent(this, IsiDataActivity::class.java),REQUEST_ADD_DATA )
            }


        kirimDataButton.setOnClickListener {
            enableRowSelection()
        }

        searchBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                // Do nothing
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                filterData(s.toString())
            }

            override fun afterTextChanged(s: Editable) {
                // Do nothing
            }
        })
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_ADD_DATA && resultCode == Activity.RESULT_OK && data != null) {
            data?.let {
                val newData = data.getSerializableExtra("new_data") as? ArrayList<String>
                if (newData != null) {
                    sampleData.add(newData.toTypedArray())
                    addTableRow(newData.toTypedArray())
                }
            }
        }
    }

    private fun initData() {
        for (data in sampleData) {
            addTableRow(data, true)
        }
    }

    private fun addTableRow(data: Array<String>, selectable: Boolean = false) {
        val tableRow = TableRow(this)

        for (column in data) {
            val textView = TextView(this)
            textView.text = column
            textView.setPadding(16, 8, 16, 8)
            tableRow.addView(textView)
        }

        if (selectable) {
            tableRow.setOnClickListener {
                if (getBackgroundColor(tableRow) == Color.YELLOW) {
                    tableRow.setBackgroundColor(Color.TRANSPARENT)
                    selectedData.remove(data)
                } else {
                    tableRow.setBackgroundColor(Color.YELLOW)
                    selectedData.add(data)
                }
            }
        }
        dataTable.addView(tableRow)
    }

    private fun filterData(query: String) {
        dataTable.removeAllViews()

        val filteredData = sampleData.filter { it[1].contains(query, ignoreCase = true) }

        for (data in filteredData) {
            addTableRow(data, true)
        }
    }

    private fun getBackgroundColor(tableRow: TableRow): Int {
        val drawable = tableRow.background
        if (drawable is ColorDrawable) {
            return drawable.color
        }
        return Color.TRANSPARENT
    }

    private fun enableRowSelection() {
        kirimDataButton.text = "Pilih Semua"
        tambahDataButton.text = "Kirim Data"
        tambahDataButton.setOnClickListener {
            val intent = Intent(this, KirimDataActivity::class.java)
            intent.putExtra("selected_data", selectedData.map { it.toList() }.toList() as Serializable)
            startActivity(intent)
        }
        kirimDataButton.setOnClickListener {
            for (i in 0 until dataTable.childCount) {
                val tableRow = dataTable.getChildAt(i) as TableRow
                tableRow.setBackgroundColor(Color.YELLOW)
                selectedData.add(
                    arrayOf(
                        (tableRow.getChildAt(0) as TextView).text.toString(),
                        (tableRow.getChildAt(1) as TextView).text.toString(),
                        (tableRow.getChildAt(2) as TextView).text.toString()
                    )
                )
            }
        }
        tambahDataButton.setOnClickListener {
            startActivityForResult(Intent(this, IsiDataActivity::class.java), REQUEST_ADD_DATA)
            val intent = Intent(this, KirimDataActivity::class.java)
            intent.putExtra("selected_data", selectedData.map { it.toList() }.toList() as Serializable)
            startActivity(intent)

            // Menampilkan notifikasi "data telah dikirim" menggunakan Toast
            Toast.makeText(this, "Data telah dikirim", Toast.LENGTH_SHORT).show()
        }

    }}
