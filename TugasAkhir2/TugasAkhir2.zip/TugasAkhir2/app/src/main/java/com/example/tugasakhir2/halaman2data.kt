package com.example.tugasakhir2

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject




class halaman2data : Fragment() {
    private lateinit var alamatEditText: EditText
    private lateinit var simpanButton: Button
    private val url = "http://10.0.2.2/ta%202/trial2.php" // Ganti dengan IP server Anda jika diperlukan

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_halaman2data, container, false)
        val nomorindek = arguments?.getString("nomorindek")
        val ibu = arguments?.getString("ibu")
        val suami= arguments?.getString("tanggal")

        val umur= arguments?.getString("umur")
        val hpht= arguments?.getString("hpht")
        val u_kehamilan = arguments?.getString("ukehamilan")
        val perkiraan= arguments?.getString("perkiraanlahir")
        val hamil_ke= arguments?.getString("hamilke")


        simpanButton = view.findViewById(R.id.simpan_button)
        alamatEditText = view.findViewById(R.id.alamat)

        simpanButton.setOnClickListener {
            val alamat = alamatEditText.text.toString()

            if (nomorindek != null) {
                if (ibu != null) {
                    if (alamat != null) {
                        if (nomorindek.isNotEmpty() && ibu.isNotEmpty() && alamat.isNotEmpty()  && suami?.isNotEmpty() == true && umur?.isNotEmpty() == true && hpht?.isNotEmpty() == true && u_kehamilan?.isNotEmpty() == true && perkiraan?.isNotEmpty() == true && hamil_ke?.isNotEmpty() == true) {
                            simpan(nomorindek, alamat, ibu, alamat)
                        } else {
                            Toast.makeText(requireContext(), "Mohon mengisi semua kolom", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

        return view
    }

    private fun simpan(nama: String,  jk: String,alamat: String,tanggal : String ) {
        val requestQueue = Volley.newRequestQueue(requireContext())
        val stringRequest = @SuppressLint("ResourceType")
        object : StringRequest(
            Request.Method.POST, url,
            Response.Listener { response ->
                val jsonObject = JSONObject(response)
                val serverResponseArray = jsonObject.getJSONArray("server_response")
                val firstObjectInArray = serverResponseArray.getJSONObject(0)
                val success = firstObjectInArray.getString("status")

                if (success == "OK" && nama.isNotEmpty() && alamat.isNotEmpty()  && alamat.isNotEmpty()  && tanggal.isNotEmpty()) {
                    val resultIntent = Intent().apply {
                        putExtra("mitoma", arrayListOf(nama, alamat, jk))
                    }
                    requireActivity().setResult(Activity.RESULT_OK, resultIntent)
                    requireActivity().finish()

                } else {
                    Toast.makeText(requireContext(), "Gagal menyimpan data", Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { error ->
                // Tampilkan pesan error
                Toast.makeText(requireContext(), "Terjadi kesalahan: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["Nomorindek"] = nama
                params["Ibu"] = ibu
                params["Suami"] = alamat
                params["JK"] = jk

                return params
            }
        }

        requestQueue.add(stringRequest)
    }
}

