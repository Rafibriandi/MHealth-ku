package com.example.tugasakhir2
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class LoginActivity : AppCompatActivity() {

    private lateinit var idEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button


    val url = "http://10.0.2.2/ta%202/login2.php" // Ganti dengan IP server Anda jika diperlukan

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        idEditText = findViewById(R.id.id)
        passwordEditText = findViewById(R.id.password)
        loginButton = findViewById(R.id.login)

        loginButton.setOnClickListener {
            val id = idEditText.text.toString()
            val password = passwordEditText.text.toString()

            login(id, password)
        }
    }

    private fun login(id: String, password: String) {
        val requestQueue = Volley.newRequestQueue(this)
        val stringRequest = object : StringRequest(
            Request.Method.POST, url,
            Response.Listener { response ->
                val jsonObject = JSONObject(response)
                val serverResponseArray = jsonObject.getJSONArray("server_response")
                val firstObjectInArray = serverResponseArray.getJSONObject(0)
                val success = firstObjectInArray.getString("status")

                if (success == "OK") {
                    // Login berhasil
                    val intent = Intent(this, MenuUtamaActivity::class.java)
                    startActivity(intent)
                    finish()
                } else {
                    // Login gagal
                    Toast.makeText(this, "ID atau password salah", Toast.LENGTH_SHORT).show()
                }
            },
            Response.ErrorListener { error ->
                // Tampilkan pesan error
                Toast.makeText(this, "Terjadi kesalahan: ${error.message}", Toast.LENGTH_SHORT).show()
            }) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["ID"] = id
                params["Password"] = password
                return params
            }
        }

        requestQueue.add(stringRequest)
    }
}