package com.example.tugasakhir2


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MenuUtamaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menuutama)

        val opsiDataButton: Button = findViewById(R.id.opsi_data)
        val opsiEdukasiButton: Button = findViewById(R.id.opsi_edukasi)

        opsiDataButton.setOnClickListener {
            val intent = Intent(this, opsidatatrialActivity::class.java)
            startActivity(intent)
        }

        opsiEdukasiButton.setOnClickListener {
            val intent = Intent(this, EdukasiActivity::class.java)
            startActivity(intent)
        }
    }
}
